import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class IntervalTest {

    @Test
    public void testcopyConstructor()
    {
        Interval intv1 = new Interval('[',0.0,2.0,']');
        Interval intv2 = new Interval(intv1);
        assertEquals(intv1.toString(), intv2.toString());
        Interval intv3 = new Interval('(',0.0,2.0,')');
        Interval intv4 = new Interval(intv3);
        assertEquals(intv3.toString(), intv4.toString());
    }
    
    
    
    
    @Test
    public void testIllegalArgumentException()
    {
        try
        {
            Interval wrong = new Interval('[',2.0,0.0,']');
            fail();
        }
        catch (IllegalArgumentException e)
        {
            assertEquals(e.getMessage(), ("Left is greater than right"));
        }
    }
    
    
    @Test
    public void testcontains()
    {
        Interval intv1 = new Interval('[',0.0,2.0,']');
        assertEquals(intv1.contains(-1.0), false);
        assertEquals(intv1.contains(3.0), false);
        assertEquals(intv1.contains(0.0), true);
        assertEquals(intv1.contains(1.0), true);
        assertEquals(intv1.contains(2.0), true);
        Interval intv2 = new Interval('(',0.0,2.0,')');
        assertEquals(intv2.contains(-1.0), false);
        assertEquals(intv2.contains(3.0), false);
        assertEquals(intv2.contains(0.0), false);
        assertEquals(intv2.contains(1.0), true);
        assertEquals(intv2.contains(2.0), false);
        Interval intv3 = new Interval('[',0.0,2.0,')');
        assertEquals(intv3.contains(-1.0), false);
        assertEquals(intv3.contains(3.0), false);
        assertEquals(intv3.contains(0.0), true);
        assertEquals(intv3.contains(1.0), true);
        assertEquals(intv3.contains(2.0), false);
        Interval intv4 = new Interval('(',0.0,2.0,']');
        assertEquals(intv4.contains(-1.0), false);
        assertEquals(intv4.contains(3.0), false);
        assertEquals(intv4.contains(0.0), false);
        assertEquals(intv4.contains(1.0), true);
        assertEquals(intv4.contains(2.0), true);
        
        // test closestTo()
        assertEquals(intv1.closestTo(3.0), 2.0, .01);
        assertEquals(intv1.closestTo(2.0), 2.0, .01);
        assertEquals(intv1.closestTo(1.0), 1.0, .01);
        assertEquals(intv1.closestTo(0.0), 0.0, .01);
        assertEquals(intv1.closestTo(-1.0), 0.0, .01);
        
        // test toString()
        assertEquals(intv1.toString(), "[  0.00,   2.00]");

               
    }


}
