/**
 * An encapsulation of a LimitedPlan (which is a MoviePlan that places a
 * limit on the amount that can be spent on credit).
 * 
 * @author Nick Albright
 * @version 1.0 2/27/18
 */
public class LimitedPlan extends MoviePlan
{
    private final double creditLimit;

    /**
     * Construct a default LimitedPlan.
     */
    public LimitedPlan()
    {
        this("Limited Plan", 5, 50.00, 15.00, 100.00);
    }

    /**
     * Construct a "pre-paid only" plan.
     * 
     * @param name     The name of the plan
     * @param prepaid  The number of pre-paid movies
     * @param planCost The cost of the plan
     */
    public LimitedPlan(String name, int prepaid, double planCost)
    {
        this(name, prepaid, planCost, 
                APPROVED_MOVIE_COSTS.closestTo(Double.MAX_VALUE), 0.00);
    }

    /**
     * Construct a LimitedPlan.
     * 
     * @param name        The name of the plan
     * @param prepaid     The number of pre-paid movies
     * @param planCost    The cost of the plan
     * @param movieCost   The cost of an extra movie
     * @param creditLimit The maximum amount that can be spent "on credit"
     */
    public LimitedPlan(String name, int prepaid,
            double planCost, double movieCost, double creditLimit)
    {
        super(name, prepaid, planCost, movieCost);
        this.creditLimit = creditLimit;
    }
    
    /**
     * Return a boolean that is true if user has credit remaining.
     * 
     * @return The boolean
     */
    private boolean limitedPlanCanUse()
    {
        if (super.remainingPrepaid() > 0)
        {
            return true;
        }
        else
        {
            return spent() + super.costOfPurchasedMovie() <= creditLimit;
        }
       
    }
    
    
    /**
     * Get a String representation of the cost of the next movie (which may
     * be pre-paid or may need to be purchased).
     * 
     * @return  The String representation
     */
    @Override
    public String getCostOfNextMovie()
    {
        if  (limitedPlanCanUse())
        {
            return super.getCostOfNextMovie();
        }
        return "N/A";
    }
    
    /**
     * Use this LimitedPlan to "see" a movie (if possible).
     * 
     *  @return  true if it is possible to "see" a movie; false otherwise
     */
    public boolean use()
    {
        if (limitedPlanCanUse())
        {
            return super.use();
        }
        return false;
    }
}
