/**
 * An enumeration of price categories.
 *
 * @author Nick Albright
 * @version 1.0 2/27/18
 */

public enum Category
{
    BARGAIN                ("Bargain", 
                            "$",
                            new Interval('[', 0.00, 5.00, ']')),
    INEXPENSIVE            ("Inexpensive",
                            "$$", 
                            new Interval('(', 5.00, 11.00, ']')),
    MODERATE                ("Moderate", 
                             "$$$",
                            new Interval('[', 11.00, 15.00, ']')),
    EXPENSIVE               ("Expensive", 
                             "$$$$",
                            new Interval('[', 15.00, 25.00, ']')),
    OUTRAGEOUS              ("Outrageous", 
                             "$$$$$",
                            new Interval('[', 25.00, Double.POSITIVE_INFINITY, ']'));
    
    
    private final Interval interval;
    private final String descriptions;
    private String symbol;
    
    
    /**
     * Explicit Value Constructor.
     *
     * @param description  A description of this Category
     * @param symbol       The symbol to use for this Category
     * @param interval     The Interval that characterizes this Category
     */
    private Category(String description, String symbol, Interval interval)
    {
        this.descriptions = description;
        this.symbol = symbol;
        this.interval = interval;
    }

    /**
     * Get the Category that corresponds to a particular price.
     * 
     * @param price      The price of interest
     * @return           The corresponding Category (or null)
     */
    public static Category getCategoryFor(double price)
    {
        for (Category cat : Category.values())
        {
            if (cat.interval.contains(price))
            {
                return cat;
            }
        }
            
        return null;
    }
    
    /**
     * Get the description of this Category.
     *
     * @return   The description
     */
    public String getDescription()
    {
        return descriptions;
    }

    /**
     * Get the symbol for this Category.
     *
     * @return   The name
     */
    public String getSymbol()
    {
        return symbol;
    }
    
    /**
     * Return a String representation of this Category.
     * 
     * @return The String representation
     */
    @Override
    public String toString()
    {
        return descriptions + " " + "(" + symbol + ")";
    }
}
