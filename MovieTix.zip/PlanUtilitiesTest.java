import static org.junit.Assert.*;

import org.junit.Test;

public class PlanUtilitiesTest {

    @Test
    public void testSpecialCasesPlanUtilities()
    {
        MoviePlan mpnull = null;
        TieredPlan tp = new TieredPlan("C", 1, 10, 15.00, 2, 5.00);
        LimitedPlan lp = new LimitedPlan("D", 1, 5, 20.00, 30.00);
        LimitedPlan nouse = new LimitedPlan("B", 2, 25.00, 15.00, 30.00);
        for (int k = 0; k < 2; k++)
        {
            tp.use();
            lp.use();
        }
        MoviePlan[] mparray = new MoviePlan[4];
        mparray[0] = mpnull;
        mparray[1] = nouse;
        mparray[2] = tp;
        mparray[3] = lp;
        assertEquals(PlanUtilities.findBestPlan(mpnull, tp, lp, nouse),
                tp);
        
        PlanUtilities constructor = new PlanUtilities();
        
        
    }

}
