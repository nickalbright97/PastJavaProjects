import static org.junit.Assert.*;

import org.junit.Test;

public class CategoryTest {

    
    @Test
    public void valueOfTest()
    {
        assertSame("valueOf(BARGAIN)", 
                Category.BARGAIN, Category.valueOf("BARGAIN"));
    }
    
    
    @Test
    public void testgetCategoryFor()
    {
        assertEquals(Category.getCategoryFor(-1.00), null);
        assertEquals(Category.getCategoryFor(0.00), 
                Category.BARGAIN);
        assertEquals(Category.getCategoryFor(5.00), 
                Category.BARGAIN);
        assertEquals(Category.getCategoryFor(5.01), 
                Category.INEXPENSIVE);
        assertEquals(Category.getCategoryFor(11.00), 
                Category.INEXPENSIVE);
        assertEquals(Category.getCategoryFor(11.01), 
                Category.MODERATE);
        assertEquals(Category.getCategoryFor(15.00), 
                Category.MODERATE);
        assertEquals(Category.getCategoryFor(15.01), 
                Category.EXPENSIVE);
        assertEquals(Category.getCategoryFor(25.00), 
                Category.EXPENSIVE);
        assertEquals(Category.getCategoryFor(25.01), 
                Category.OUTRAGEOUS);
        assertEquals(Category.getCategoryFor(9999.99), 
                Category.OUTRAGEOUS);
        
    }
    
    @Test
    public void testtoString()
    {
        assertEquals(Category.BARGAIN.toString(), 
                "Bargain ($)");
        assertEquals(Category.INEXPENSIVE.toString(), 
                "Inexpensive ($$)");
        assertEquals(Category.MODERATE.toString(), 
                "Moderate ($$$)");
        assertEquals(Category.EXPENSIVE.toString(), 
                "Expensive ($$$$)");
        assertEquals(Category.OUTRAGEOUS.toString(), 
                "Outrageous ($$$$$)");
    }
    
    @Test
    public void testgetDescription()
    {
        assertEquals(Category.BARGAIN.getDescription(), 
                "Bargain");
        assertEquals(Category.INEXPENSIVE.getDescription(), 
                "Inexpensive");
        assertEquals(Category.MODERATE.getDescription(), 
                "Moderate");
        assertEquals(Category.EXPENSIVE.getDescription(), 
                "Expensive");
        assertEquals(Category.OUTRAGEOUS.getDescription(), 
                "Outrageous");
    }
    
    @Test
    public void testgetSymbol()
    {
        assertEquals(Category.BARGAIN.getSymbol(), 
                "$");
        assertEquals(Category.INEXPENSIVE.getSymbol(), 
                "$$");
        assertEquals(Category.MODERATE.getSymbol(), 
                "$$$");
        assertEquals(Category.EXPENSIVE.getSymbol(), 
                "$$$$");
        assertEquals(Category.OUTRAGEOUS.getSymbol(), 
                "$$$$$");
    }

}
