import static org.junit.Assert.*;

import org.junit.Test;

public class TieredPlanTest {

    @Test
    public void testTieredPlan()
    {
        TieredPlan tp = new TieredPlan();
        for (int i = 0; i < 5; i++)
        {
            tp.use();
        }
        assertEquals(tp.costOfPurchasedMovie(), 5.50, .01);
        for (int i = 0; i < 5; i++)
        {
            tp.use();
        }
        assertEquals(tp.costOfPurchasedMovie(), 10.00, .01);
    }

}
