/**
 * An encapsulation of a MoviePlan in which the price of the purchased movies
 * is "tiered" -- the first few purchases are less expensive than subsequent
 * purchases.
 *
 * @author   
 * @version  
 */
public class TieredPlan extends MoviePlan
{
    
    private final double tierCost;
    private final int tierLimit;
    
    
    /**
     * Default Constructor.
     */
    public TieredPlan()
    {
        this("Tiered Plan", 5, 100.00, 10.00, 5, 5.50);
    }
    
    /**
     * Explicit Value Constructor.
     * 
     * @param name      The name of this TieredPlan
     * @param prepaid   The number of pre-paid movies to start
     * @param planCost  The up-front cost of this TieredPlan
     * @param movieCost The price per movie of extra movies (after the first tier is used)
     * @param tierLimit The number of extra movies that can be purchased at the reduced price
     * @param tierCost The reduced price for the first tierLimit number of movies purchased 
    */
    public TieredPlan(String name, int prepaid, double planCost, double movieCost,
            int tierLimit, double tierCost)
    {
        super(name, prepaid, planCost, movieCost);
        this.tierLimit = tierLimit;
        this.tierCost = APPROVED_MOVIE_COSTS.closestTo(tierCost);
    }
    
    /**
     * Return the current cost of a purchased (i.e., not pre-paid) extra movie.
     * 
     * @return  The cost
     */
    @Override
    protected double costOfPurchasedMovie()
    {
        if (numberPurchased() < tierLimit)
        {
            return tierCost;
        }

        return super.costOfPurchasedMovie();
        
    }
}
