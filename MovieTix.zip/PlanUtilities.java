/**
 * A utility class that contains methods for working with
 * MoviePlan objects.
 * 
 * @author  Nick Albright
 * @version 1.0 2/18/18
 *
 */
public class PlanUtilities
{
     /**
     * Find the least expensive MoviePlan (based on its current state).
     * 
     * @param  plans  The MoviePlan objects to consider
     * @return        The least expensive MoviePlan    
     */
    public static MoviePlan findBestPlan(MoviePlan... plans)
    {
        MoviePlan optimalPlan = null;
        double bestCPM = Double.MAX_VALUE;
        for (int k = 0; k < plans.length; k++)
        {
            if (plans[k] != null)
            {
                try
                {
                    if (plans[k].getCostPerMovie() < bestCPM)
                    {
                        optimalPlan = plans[k];
                        bestCPM = plans[k].getCostPerMovie();
                    }
                
                }
                catch (IllegalStateException e)
                {
                     // do nothing, ignore
                }
            }
        }
        
        return optimalPlan;
    }
}
