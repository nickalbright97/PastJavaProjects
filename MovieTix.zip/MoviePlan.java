/**
 * An encapsulation of a MoviePlan.
 *
 * @author Nick Albright  
 * @version 1.0 2/27/18 
 */
public class MoviePlan
{
    
    protected final static Interval APPROVED_MOVIE_COSTS = 
            new Interval('[', 0.00, 25.00, ']');
    protected final static Interval APPROVED_PLAN_COSTS = 
            new Interval('[', 0.00, 200.00, ']');
    private final double movieCost;
    private final double planCost;
    private final int prepaid;
    private final String name;
    private double spent;
    private int numberPurchased;
    private int punches;


    /**
     * Default Constructor.
     */
    public MoviePlan()
    {
        this("Movie Plan", 5, 50.00, 15.00);
    }

    /**
     * Explicit Value Constructor.
     * 
     * @param name      The name of this MoviePlan
     * @param prepaid   The number of pre-paid movies
     * @param planCost  The up-front cost of the plan
     * @param movieCost The cost of an additional movie
     */
    public MoviePlan(String name, int prepaid, double planCost, double movieCost)
    {
        this.name = name;
        this.prepaid = prepaid;
        this.planCost = APPROVED_PLAN_COSTS.closestTo(planCost);
        this.movieCost = APPROVED_MOVIE_COSTS.closestTo(movieCost);
        
        numberPurchased = 0;
        punches = 0;
        spent = 0.00;
    }

    /**
     * Return the cost of a purchased (i.e., not pre-paid) movie.
     * 
     * @return  The cost
     */
    protected double costOfPurchasedMovie()
    {
        return movieCost;
    }

    /**
     * Return the cost-to-date associated with this MoviePlan based on its
     * use-to-date.
     * 
     * @return  The cost-to-date
     */
    protected double costToDate()
    {
        return spent() + getPlanCost();
    }


    /**
     * Get the current Category of this MoviePlan based on the cost per movie to-date.
     * 
     * @return  The Category
     * @throws IllegalStateException if 0 movies have been seen
     */
    public Category getCategory() throws IllegalStateException
    {        
        return Category.getCategoryFor(getCostPerMovie());
    }

    /**
     * Get a String representation of the cost of the next movie (which may
     * be pre-paid or may need to be purchased).
     * 
     * @return The String representation
     */
    public String getCostOfNextMovie()
    {
        if (remainingPrepaid() > 0)
        {
            return "Free";
        }
        
        return String.format("$%6.2f", costOfPurchasedMovie());
    }

    /**
     * Get the cost per movie associated with this MoviePlan based on its
     * use-to-date.
     * 
     * @return The cost per movie
     * @throws IllegalStateException  If no movies have been seen
     */
    public double getCostPerMovie() throws IllegalStateException
    {
        if (numberSeen() == 0)
        {
            throw new IllegalStateException();
        }
        return costToDate() / (double) numberSeen();
    }

    /**
     * Get the name of this MoviePlan.
     * 
     * @return  The name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Get the up-front cost of this MoviePlan.
     * 
     * @return  The up-front cost
     */
    public double getPlanCost()
    {
        return planCost;
    }

    /**
     * Return the number of movies that have been purchased (i.e., seen
     * but not pre-paid).
     * 
     * @return  The number of purchased movies
     */
    protected int numberPurchased()
    {
        return numberPurchased;
    }

    /**
     * Return the number of movies that have been seen (both pre-paid
     * and otherwise).
     * 
     * @return  The number of movies that have been seen
     */
    protected int numberSeen()
    {
        return numberPurchased() + punches;
    }

    /**
     * Return the number of remaining pre-paid movies.
     * 
     * @return The number of remaining pre-paid movies
     */
    protected int remainingPrepaid()
    {
        return prepaid - punches;
    }

    /**
     * Get the amount of money that has been spent on "extra" movies
     * (i.e., over and above the movies that were pre-paid).
     * 
     * @return The amount spent
     */
    protected double spent()
    {
        return spent;
    }

    /**
     * Return a String representation of this MoviePlan.
     * 
     * @return  The String representation
     */
    @Override
    public String toString()
    {
   
        if (numberSeen() == 0)
        {
            return  getName() 
                    + "\t" + "\t"
                    + "Unused" + getCostOfNextMovie(); 
        }
        
        return getName() 
                + "\t" + String.format("$%6.2f", getCostPerMovie())
                + "\t" + getCategory().getDescription()
                + "\t" + getCostOfNextMovie();
        
    }

    /**
     * Use this MoviePlan to "see" a movie (if possible).
     * 
     *  @return  true if it is possible to "see" a movie; false otherwise
     */
    public boolean use()
    {
        if (remainingPrepaid() > 0)
        {
            punches += 1;
        }
        else
        {
            spent += costOfPurchasedMovie();
            numberPurchased += 1;
        }
        return true;
    }
}
