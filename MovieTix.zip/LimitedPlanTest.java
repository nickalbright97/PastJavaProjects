import static org.junit.Assert.*;

import org.junit.Test;

public class LimitedPlanTest {

    @Test
    public void testLimitedPlan()
    {
        LimitedPlan thrParam = new LimitedPlan("A", 1, 10.00);
        assertEquals(thrParam.getName(), "A");
        LimitedPlan lp = new LimitedPlan();
        assertEquals(lp.getCostOfNextMovie(), "Free");
        for (int user = 0; user < 12; user++)
        {
            lp.use();
        }
        assertEquals(lp.getCostOfNextMovie(), "N/A");

    }

}
