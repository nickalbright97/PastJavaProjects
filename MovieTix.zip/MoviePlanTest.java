import static org.junit.Assert.*;

import org.junit.Test;

public class MoviePlanTest {

    @Test
    public void testMoviePlan()
    {
        MoviePlan mp = new MoviePlan("A", 2, 20.00, 12.50);
        assertEquals(mp.toString(), "A" + "\t" + "\t" + "Unused" + "Free");
        assertEquals(mp.getCostOfNextMovie(), "Free");
        assertEquals(mp.getName(), "A");
        assertEquals(mp.getPlanCost(), 20.00, .01);
        assertEquals(mp.costOfPurchasedMovie(), 12.50, .01);
        assertEquals(mp.costToDate(), 20.00, .01);
        mp.use();
        mp.use();
        mp.use();
        assertEquals(mp.getCostOfNextMovie(), "$ 12.50");
        assertEquals(mp.getCostPerMovie(), 10.83, .01);
        assertEquals(mp.numberPurchased(), 1);
        assertEquals(mp.costToDate(), 32.50, .01);
        assertEquals(mp.getCategory(), Category.INEXPENSIVE);
        assertEquals(mp.numberPurchased(), 1);
        assertEquals(mp.toString(),
                "A" + "\t" + "$ 10.83" + "\t" + "Inexpensive" + "\t" +  "$ 12.50");
        MoviePlan mpbasic = new MoviePlan();
        assertEquals(mpbasic.getName(), "Movie Plan");
        
        
    }

}
