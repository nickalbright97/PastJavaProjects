/**
 * An immutable encapsulation of an interval (that can be open,
 * closed, or half-open/closed).
 *
 * @author Nick Albright
 * @version 1.0 2/27/18
 */

public class Interval
{
    private final double left;
    private final double right;
    private final boolean leftClosed;
    private final boolean rightClosed;

    /**
     * Copy constructor.
     *
     * @param original    The Interval to copy
     */
    public Interval(Interval original)
    {
        this(original.getLeftSymbol(), original.left, original.right,
                 original.getRightSymbol());
    }
    
    /**
     * Construct an interval.
     *
     * @param leftSymbol  [ or (
     * @param left        The lower bound
     * @param right       The upper bound
     * @param rightSymbol ] or )
     * @throws IllegalArgumentException  if left > right
     */
    public Interval(char leftSymbol, double left, 
                    double right, char rightSymbol) throws IllegalArgumentException
    {
        if (left > right)
        {
            throw new IllegalArgumentException("Left is greater than right");
        }
        this.left = left;
        this.right = right;
      
        if (leftSymbol == '[')
        {
            leftClosed = true;
        }
        else
        {
            leftClosed = false;
        }

        if (rightSymbol == ']')
        {
            rightClosed = true;
        }
        else
        {
            rightClosed = false;
        }
    }
    
    /**
     * Private helper method for copy constructor.
     *  
     * @return char that is [ if interval is left closed
     */
    private char getLeftSymbol()
    {
        if (leftClosed)
        {
            return '[';
        }
        return '(';
    }
    
    /**
     * Private helper method for copy constructor.
     *  
     * @return char that is ] if interval is right closed
     */
    private char getRightSymbol()
    {
        if (rightClosed)
        {
            return ']';
        }
        return ')';
    }
    
    /**
     * Returns true if the given value is contained in this Interval
     * and false otherwise.
     *
     * Note that this method does not use tolerances. Hence, it is
     * not appropriate for some kinds of calculations.
     *
     * @param  value  The value to check
     * @return        true if the value is in the interval; false otherwise
     */
    public boolean contains(double value)
    {

        if (value > right || value < left)
        {
            return false;
        }
        
        if (value == right)
        {
            return rightClosed;
        }
        
        if (value == left)
        {
            return leftClosed;
        }
        
        return true;
    }

    /**
     * Returns the value in the closure of the Interval (i.e., the
     * Interval and its end points) that is closest to the given
     * number.
     *
     * @param number   The number of interest
     * @return         The value in the closure that is closest to the number
     */
    public double closestTo(double number)
    {
        if (contains(number))
        {
            return number;
        }
        if (number >= right)
        {
            return right;
        }
        else
        {
            return left;
        }

    }

    /**
     * Return a String representation of this Interval.
     * 
     * @return  The String representation
     */
    @Override
    public String toString()
    {
        return toString("%6.2f");
    }
    
    /**
     * Return a String representation of this Interval.
     *
     * @param fs  The format String to use
     * @return          The String representation
     */
    public String toString(String fs)
    {
        String output = String.valueOf(getLeftSymbol());
        output += String.format(fs, left);
        output += ", ";
        output += String.format(fs, right);
        output += String.valueOf(getRightSymbol());
        return output;
    }
}
