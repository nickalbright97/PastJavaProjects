
public class Tester
{

    public static void main(String[] args)
    {
        /**
        Interval intv;
        intv = new Interval('[',0.0,2.0,']');
        System.out.print(intv.toString());
        
        
       // Category cat = Category.getCategoryFor(999999.9);
       // System.out.print(cat.toString());
        
        
         
        
        
        MoviePlan mp = new MoviePlan("A", 2, 20.00, 12.50);
        
        int x = 3;
        for (int k = 0; k < x; k++)
        {
            mp.use();

            System.out.print(mp.toString());
            System.out.print("\n");

        }
        */
        
                 
        LimitedPlan lp = new LimitedPlan("C", 2, 30.00);
        int x = 5;
        for (int k = 1; k < x; k++)
        {
            
            System.out.print(lp.toString());
            System.out.print("\n");
        }
        
        //System.out.print(tp.toString());
         
        
        
        
        
        
        

        
    }

}
