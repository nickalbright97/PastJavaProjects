/**
 * An mutable encapsulation of student and his attributes.
 * 
 * @author  Nick Albright
 * @version January 17, 2018
 */
public class Student 
{
    
    private int[] seat;

    private Posse friends;

    private String name;
    
    /**
     * Construct a Student with row and column.
     * 
     * @param name The string name of the student.
     * @param row  The int row of the student.
     * @param column The int column of the student.
     */
    public Student(String name, int row, int column) 
    {
        this.name = name;
        seat = new int[2];
        seat[0] = row;
        seat[1] = column;
        if (row < 0) 
        {
            seat[0] = 0;
        }
        if (column < 0) 
        {
            seat[1] = 0;
        }
        friends = new Posse();
       
    }
    
    /**
     * Construct a Student with row and column of 0.
     * 
     * @param name The string name of the student.
     */
    public Student(String name) 
    {
        this(name, 0, 0);
    }
    
    /**
     * Add a friend to the Posse as long as it's not their own.
     * 
     * @param friend The friend object to be added
     */
    public void addFriend(Student friend) 
    {
        if (!(this.equals(friend))) 
        {
            friends.add(friend); 
        }       
    } 
    
    public void addFriends(Student[] friends)
    {
    	if (friends != null) // watch nullpointer
    	{
    		for (int k = 0; k < friends.length; k++)
        	{
    			addFriend(friends[k]);        	    
        	}
    	}
    	
    }
    
    public String toString()
    {
    	String str = ""; // can we assume this won't be passed a null?
    	str += this.getName() + ":" + friends.toString();
    	return str;
    }
    
    /**
     * See if student object equals other student object.
     * 
     * @param other The other student being compared
     * @return A boolean that is true if students are equal
     */
    public boolean equals(Student other) 
    {
        boolean b = false;
        if (name.equals(other.getName())) 
        { 
            b = true;
        }
        return b;
    }
    
    /**
     * Get the row a student is sitting in.
     * 
     * @return An int that represents the row.
     */
    public int getRow() 
    {
        int row;
        row = seat[0];
        return row;
    }
    
    /**
     * Get the column a student is sitting in.
     * 
     * @return An int that represents the column.
     */
    public int getColumn() 
    {
        int column;
        column = seat[1];
        return column;
    }
    
    /**
     * Get the name of a student.
     * 
     * @return A string of the name
     */
    public String getName() 
    {
        String n;
        n = name;
        return n;
    }
    
    /**
     * Set the column the student is sitting in.
     * 
     * @param column An int that represents the column.
     */
    public void setColumn(int column) 
    {       
        seat[1] = column;
        if (column < 0) 
        {
            seat[1] = 0;
        }
    }
    
    /**
     * Set the row the student is sitting in.
     * 
     *@param row An int that represents the row.
     */
    public void setRow(int row) 
    {       
        seat[0] = row;
        if (row < 0) 
        {
            seat[0] = 0;
        }
    }
    
    /**
     * Get the unhappiness of the student.
     * 
     * @return A double that represents the unhappiness.
     */
    public double getUnhappiness() 
    {
        double unhap = 0.0;
        int[] t;
        t = new int[2];
        for (int i = 0; i < friends.getSize(); i++) 
        {
            t[0] = (friends.get(i)).getRow();
            t[1] = (friends.get(i)).getColumn();
            unhap += Social.distance(seat, t);
        }
        return unhap;
    }
    

            
        
        
    
    
    
        
        
    
}

