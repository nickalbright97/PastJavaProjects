import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.zip.DataFormatException;

/**
 * A method to find better seating arrangements.
 * 
 * @author  Nick Albright
 * @version January 29, 2018
 */
public class SeatingChart
{

    private Student[][] seats;
    
    /**
     * Construct a Seating charts with rows and columns.
     * 
     * @param rows The number of rows in the seating chart
     * @param columns The number of columns in the seating chart
     */
    public SeatingChart(int rows, int columns)
    {
        seats = new Student[rows][columns];
    }
    
    /** This constructs a seating chart from an input filename which represents a
     *  .sr3 file of specified format and can throw exceptions if file isn't found
     *  or format doesn't match expected.
     * 
     * @param fileName - a String which represents the pathname of the file
     * @throws FileNotFoundException - if File can't be found
     * @throws DataFormatException - if data isn't formatted correctly
     */
    public SeatingChart(String fileName) throws FileNotFoundException, DataFormatException
    {       
        this(getRowsFile(fileName), getColsFile(fileName));        
        
        int rows = getRowsFile(fileName);
        int columns = getColsFile(fileName);
        Scanner reader = new Scanner(new File(fileName));        
        String[] splitArray;
        String str;
        int check;
        
        // Check size block
        try
        {
            check = reader.nextInt();
        }
        catch(InputMismatchException e)
        {
        	reader.close();
            throw new DataFormatException();
        }
        
        try
        {
            check = reader.nextInt();
        }
        catch(InputMismatchException e)
        {
        	reader.close();
            throw new DataFormatException();
        }
        
        str = reader.nextLine();
        try
        {
            str = reader.nextLine();
        }
        catch(NoSuchElementException e)
        {
        	reader.close();
            throw new DataFormatException();
        }
        
        if (!str.equals(""))
        {
            reader.close();
            throw new DataFormatException();
        }
        
        
        int counter = 0;
        for (int rowCounter = 0; rowCounter < rows; rowCounter++)
        {
        	str = reader.nextLine();
        	splitArray = str.split(",");
        	if (splitArray.length != columns)
        	{
        	    reader.close();
        	    throw new DataFormatException();
        	}
        	for (int columnCounter = 0; columnCounter < columns; columnCounter++)
        	{
        		if (!splitArray[columnCounter].equals("-"))
        		{
        		    Student student;
        		    student = new Student(splitArray[columnCounter],rowCounter,columnCounter);
        		    //if (getStudent(student.getName()) != null)
        		    if (getStudent(splitArray[columnCounter]) != null)
        		    {
        		    	reader.close();
        	            throw new DataFormatException();
        		    }
        	        placeStudent(rowCounter,columnCounter,student);        	   
        	        counter += 1;
        		}
        	}
        }
        
        
        str = reader.nextLine();  // skips line
        if (!str.equals(""))
        {
        	reader.close();
            throw new DataFormatException();
        }
        
        String name;
        Student addedTo;
        Student[] addHomies;
        String[] secondSplit;
        int k = 0;
        while (k < counter) // iterates as many times as non-dashes were in src
        {
        	str = reader.nextLine();
        	splitArray = str.split(":");
        	name = splitArray[0];
        	addedTo = getStudent(name);
        	if (addedTo == null)
    		{
    			reader.close();
    	        throw new DataFormatException();
    		} 
        	if (splitArray.length > 1) // checks for no friend condition
        	{
            	secondSplit = splitArray[1].split(",");
            	addHomies = new Student[secondSplit.length];
            	for (int i = 0; i < secondSplit.length; i++)
            	{
            		addHomies[i] = getStudent(secondSplit[i]);
            		if (addHomies[i] == null)
            		{
            			reader.close();
            	        throw new DataFormatException();
            		}          		
            	}
            	addedTo.addFriends(addHomies);            	
        	}
        	k += 1;	
        }
        
        if (reader.hasNextLine())
        {
	        reader.close();
	        throw new DataFormatException();
	    }
        reader.close();
    }
    
    /** This constructs a seating chart from an input .sr3 file of 
     *  specified format and can throw exceptions if file isn't found
     *  or format doesn't match expected.
     * 
     * @param file - the file being turned into the seating chart
     * @throws FileNotFoundException - if File can't be found
     * @throws DataFormatException - if data isn't formatted correctly
     */
    public SeatingChart(File file) throws FileNotFoundException, DataFormatException
    {
    	this(getPathName(file));
    }
    
    
    /** Private helper method which finds Rows from file
     *  specified by fileName string.
     *  
     * @param fileName - A String that is the address of a file
     * @return an Int which represents the row specifier in the file
     * @throws FileNotFoundException if the file cannot be found from fileName
     */
    private static int getRowsFile(String fileName) throws FileNotFoundException, DataFormatException
    {
    	int rows;
        Scanner rowReader = new Scanner(new File(fileName));
    	
    	String str = rowReader.nextLine();
        String[] splitArray = str.split(" ");
        if (splitArray.length != 2)
        {
        	rowReader.close();
	        throw new DataFormatException();           
        }
       
        try
        {
            rows = Integer.parseInt(splitArray[0]);
        }
        catch(NumberFormatException e)
        {
        	rowReader.close();
	        throw new DataFormatException(); 
        }
        rowReader.close();
        
    	if (rows < 1)
    	{
	        throw new DataFormatException();
    	}
        
    	return rows;
    }
    
    /** Private helper method which finds Columns from file
     *  specified by fileName string.
     *  
     * @param fileName - A String that is the address of a file
     * @return an Int which represents the row specifier in the file
     * @throws FileNotFoundException if the file cannot be found from fileName
     */
    private static int getColsFile(String fileName) throws FileNotFoundException, DataFormatException
    {
    	int cols;
        Scanner colReader = new Scanner(new File(fileName));
    	
    	String str = colReader.nextLine();
        String[] splitArray = str.split(" ");
        
        try
        {
            cols = Integer.parseInt(splitArray[1]);
        }
        catch(NumberFormatException e)
        {
        	colReader.close();
	        throw new DataFormatException(); 
        }
        
        colReader.close();
        
        if (cols < 1)
    	{
    		colReader.close();
	        throw new DataFormatException();
    	}
        
    	
    	return cols;
    }
    
    /** Private helper method which gets the pathname from
     *  a given File object.
     *  
     * @param file - the file object used
     * @return a String that is the pathname of the file object
     * @throws FileNotFoundException if the file cannot be found
     */
    private static String getPathName(File file) throws FileNotFoundException
    {
    	String pathname = file.getAbsolutePath(); // should i use getPath()?
    	return pathname;
    }
    
    
    public Student getStudent(String name)
    {
    	Student checkStudent;
    	Student returnStudent = null;
    	for (int rows = 0; rows < getRows(); rows++)
    	{
    		for (int cols = 0; cols < getColumns(); cols++)
    		{
    			if (seats[rows][cols] != null)
    			{
    				checkStudent = getStudent(rows,cols);
    				if (checkStudent.getName().equals(name))
    				{
    					returnStudent = checkStudent;
    				}
    			}
    		}
    	}
    	return returnStudent;
    }
    
    public String toString()
    {
        String ret = "";
        for (int rows = 0; rows < getRows(); rows++)
        {
        	ret += SitRiteStringUtils.studentsToDelimitedString(seats[rows],
        			0, getColumns(), ",");
        	ret += "\n";
        }
        	
    	return ret;
    }
    
    public String toStringVerbose()
    {
    	String ret = "";
    	ret += Integer.toString(getRows()) + " " + Integer.toString(getColumns());
    	ret += "\n\n";
    	ret += toString() + "\n";
    	
    	// Arrange Friends list at bottom
    	ArrayList<Student> posseOwners;
    	posseOwners = new ArrayList<Student>();
    	for (int rows = 0; rows < getRows(); rows++)
    	{
    		for (int cols = 0; cols < getColumns(); cols++)
    		{
    			if (getStudent(rows,cols) != null)
    			{
    				posseOwners.add(getStudent(rows,cols));
    			}
    		}
    	}
    	
    	// Figure out seat order in friends list for part B
    	for (int k = 0; k < posseOwners.size(); k++)
    	{
    		ret += posseOwners.get(k).toString() + "\n";		
    	}
    	return ret;
    }
    
    public void save(String fileName) throws FileNotFoundException
    {
    	PrintWriter writer = new PrintWriter(fileName);
    	writer.print(toStringVerbose());
    	writer.close();    	
    }
    
    public void save(File file) throws FileNotFoundException
    {
    	save(getPathName(file));
    }
    
    public void export(String fileName) throws FileNotFoundException
    {
    	PrintWriter writer = new PrintWriter(fileName);
    	writer.print(toString());
    	writer.close();    	
    }
    
    public void export(File file) throws FileNotFoundException
    {
    	export(getPathName(file));
    }

    /**
     * Get the number of rows in the seating chart.
     * 
     * @return int The number of rows in the chart
     */
    public int getRows()
    {
    	if (seats == null)
    	{
    		return 0;
    	}       
        return seats.length;
    }
    
    /**
     * Get the number of columns in the seating chart.
     * 
     * @return int The number of columns in the chart
     */
    public int getColumns()
    {
    	if (seats == null)
    	{
    		return 0;
    	}       
        return seats[0].length;
    }
    
    /**
     * Get the number of rows in the seating chart.
     * 
     * @param row An int that is the row of the desired student
     * @param column An int that is the column of the desired student
     * @return Student The student desired from the chart
     */
    public Student getStudent(int row, int column)
    {
        if (this.isValid(row, column))
        {
            return seats[row][column];
        }
        return null;
    }
    
    /**
     * Determine whether the given position is in the bounds of the
     * seating chart.
     * 
     * @param row An int that is the row of checked seat
     * @param column An int that is the column of the checked seat
     * @return boolean Whether the position is valid
     */
    private boolean isValid(int row, int column)
    {
        if (row >= this.getRows() || column >= this.getColumns()
             || row < 0 || column < 0)
        {
            return false;
        }
        return true;
    }
    
    /**
     * Places a student in a given position on the chart.
     * 
     * @param row An int that is the row of the placed seat
     * @param column An int that is the column of the placed seat
     * @param student A student object to be placed in a seat
     */
    public void placeStudent(int row, int column, Student student)
    {
        if (this.isValid(row, column))
        {
            seats[row][column] = student;
            if (student != null)
            {
            	student.setRow(row);
                student.setColumn(column);
            }
        }
        
    }
    
    /**
     * Go through the whole chart and get total unhappiness.
     * 
     * @return double The unhappiness of the chart
     */
    public double getTotalUnhappiness()
    {
        double d = 0;
        for (int row = 0; row < this.getRows(); row++)
        {
            for (int col = 0; col < this.getColumns(); col++)
            {
                if (seats[row][col] != null)
                {
                    d += seats[row][col].getUnhappiness();
                }
            }
        }
        return d;
    }
    
    /**
     * Swap two students in the chart, even if null.
     * 
     * @param row1 An int that is the row of student 1
     * @param column1 An int that is the column of student 1
     * @param row2 An int that is the row of student 2
     * @param column2 An int that is the column of student 2
     */
    public void swap(int row1, int column1, int row2, int column2)
    {
    	if (this.isValid(row1, column1) 
                && this.isValid(row2, column2))
    	{
    		Student student1;
            Student student2;
            student1 = this.getStudent(row1, column1);
            student2 = this.getStudent(row2, column2);
            placeStudent(row1, column1, student2);
            placeStudent(row2, column2, student1);
    	}
    }
    
    /**
     * Iterate throughout the chart making swaps between students
     * if the swap will decrease the total unhappiness.
     */
    public void stepGreedy()
    {
        for (int row = 0; row < this.getRows(); row++)
        {
            for (int col = 0; col < this.getColumns(); col++)
            {
                double unhapCounter = this.getTotalUnhappiness();
                int swapRow = row;
                int swapCol = col;                        
                for (int i = -1; i < 2; i++)
                {
                    for (int k = -1; k < 2; k++)
                    {
                        if (isValid(row + i, col + k))
                        {
                            this.swap(row, col, row + i, col + k);
                            if (this.getTotalUnhappiness() < unhapCounter)
                            {
                                unhapCounter = this.getTotalUnhappiness();
                                swapRow = row + i;
                                swapCol = col + k;
                            }
                            this.swap(row, col, row + i, col + k);
                        }
                        
                    }
                }
                this.swap(row, col, swapRow, swapCol);   
            }
        }
    }        
    
    /**
     * Repeatedly call stepGreedy() until no more improvements are
     * being made.
     */    
    public void solveGreedy()
    {
        boolean a = true;
        double unhap;
        while (a)
        {
            unhap = this.getTotalUnhappiness();
            this.stepGreedy();
            if (unhap <= this.getTotalUnhappiness())
            {
                a = false;
            }
                 
        }
    }
    
    
}
