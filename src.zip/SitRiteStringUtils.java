
public class SitRiteStringUtils {
	
	public static String studentsToDelimitedString(Student[] students,
			int offset, int length, String delim)
	{		
		String str = ""; // initialize as null?
		if (students == null || delim == null) // should return null if delim invalid?
		{
			return null;
		}
		for (int k = offset; k < offset + length; k++)
		{
			if (students[k] == null)
			{
			    str += "-";
			}
			else
			{
				str += students[k].getName();
			}
			if (k < offset + length - 1)
			{
				str += delim;				
			}

		}
		return str;
	}
	
	public static String studentsToDelimitedString(Student[] students, String delim)
	{
		if (students == null || delim == null) // should return null if delim invalid?
		{
			return null;
		}
		String str = studentsToDelimitedString(students,
				0, students.length, delim);
		return str;
	}
}
