/**
 * A utility class that calculates euclidean distance.
 * 
 * @author  Nick Albright
 * @version January 17, 2018
 */
 
public class Social  
{
    
    /**
     * Calculate euclidean distance.
     * 
     * @param s Two-element array of x and y position.
     * @param t Two-element array of x and y position.
     * @return A double which represents euclidean distance.
     */
    public static double distance(int[] s, int[] t)  
    {
        
        double d;
        d = Math.sqrt((Math.pow(s[0] - t[0], 2)) + (Math.pow(s[1] - t[1], 2)));
        
        return d;
    }
}

