/**
 * A class which creates and transforms a student's Posse.
 * 
 * @author  Nick Albright
 * @version January 17, 2018
 */
 
public class Posse 
{
    
    private final int DEFAULT_SIZE = 100;
    
    private int size;
    
    private Student[] members;

    /**
     * Construct a Posse.
     * 
     * @param maxSize The maximum size of the Posse
     */    
    public Posse(int maxSize) 
    {
        members = new Student[maxSize];
        size = 0;
    }
   
    /**
     * Construct a Posse of default size.
     * 
     */
    public Posse() 
    { //need to avoid code duplication here
        members = new Student[DEFAULT_SIZE];
        size = 0;
    }
    
    /**
     * Add a student to the Posse if the student is not already 
     * in the Posse and the Posse is not full and return false if the Posse
     * is full and true otherwise.
     * 
     * @param student Student to be added
     * @return A boolean which is false if the Posse is full and true otherwise
     */
    public boolean add(Student student) 
    {
        boolean a;
        boolean b;
        b = true;
        if (size == members.length) 
        {
            b = false;
        }
        a = !(this.contains(student));
        if (a && b) 
        {
            members[size] = student;
            size++;
        }
        return b;
    }
    
    /**
     * Get the size of a student's Posse.
     *      
     * @return An int that represents the size.
     */
    public int getSize() 
    {
        return size;
    }
    
   /**
     * Get the index of a Student in a Posse.
     * 
     * @param name A string that represents the student's name
     * @return An int that represents the index.
     */
    private int getIndex(String name) 
    { 
        int d = -1;
        for (int i = 0; i < size; i++) 
        {
            if (name.equals(members[i].getName())) 
            {
                d = i;
            }
        }
        return d;
    }    
    
    /**
     * Get the Student of a certain index in a Posse.
     * 
     * @param index An int that represents the index
     * @return A Student
     */
    public Student get(int index) 
    {
        Student student;
        student = null;
        if ((index > -1) && (index < members.length)) 
        {
            student = members[index];
        }
        return student;
    }
    
    /**
     * Get the Student of a certain name in a Posse.
     * 
     * @param name A string that represents the name.
     * @return A Student
     */   
    public Student get(String name) 
    {
        Student student;
        int id = this.getIndex(name);
        student = get(id);
        return student;       
    }
    
    /**
     * Verify whether a posse contains a student.
     * 
     * @param student The student being looked for.
     * @return A boolean which is true if the student is in the Posse.
     */   
    public boolean contains(Student student) 
    {        
        boolean a = true;
        if (student == null) 
        {
            a = false;
            return a;
        } else 
        { 
            String name = student.getName();
            if (get(name) == null) 
            {
                a = false;
            }
            return a;
        }
        
    }
    
    /* This method returns a comma-delimited string of the Posse.
     * 
     * @return A String which contains the Posse
     */
    public String toString()
    {    	
    	String str = SitRiteStringUtils.studentsToDelimitedString(members, 0, getSize(), ",");
    	return str;
    }
    
       
}
