
/**
 * Creates a ship object, controlled by the player.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public class Ship extends GameElement
{
    private static final double COLLISION_RADIUS = 10;
    private static final double SHIP_BASE = 10;
    private static final double SHIP_HEIGHT = 20;
    private static final int VK_LEFT = 37;
    private static final int VK_RIGHT = 39;
    private static final int VK_DOWN = 40;
    
    
    /**
     * Create a ship object using the superconstructor.
     * 
     */
    public Ship()
    {
        super(new Pose(GameConstants.SCREEN_WIDTH / 2,
                GameConstants.SCREEN_HEIGHT / 2, Math.PI / 2), 
                new Vector2D(0, 0), COLLISION_RADIUS);
    }
    
    /**
     * Turn the ship.
     * 
     * @param angle - the angle to be turned
     */
    public void turn(double angle)
    {
        pose.setHeading(pose.getHeading() + angle);
    }
    
    /**
     * Thrust the ship.
     * 
     * @param acceleration - the magnitude of acceleration
     */
    public void thrust(double acceleration)
    {
        GameUtils.applyThrust(velocity, 
                new Vector2D(pose.getHeading(), acceleration));
    }
    
    /**
     * Update the ship's position, heading, and thrust.
     * 
     * 
     * @see GameElement#update()
     */
    public void update()
    {
        if (StdDraw.isKeyPressed(VK_LEFT))
        {
            turn(.1);
        }
        
        if (StdDraw.isKeyPressed(VK_RIGHT))
        {
            turn(-.1);
        }
        
        if (StdDraw.isKeyPressed(VK_DOWN))
        {
            thrust(.1);
        }
        else
        {
            velocity.setMagnitude(velocity.getMagnitude() * .99);
        }
                              
        super.update();
    }
    
    /**
     * Draw the ship element.
     * 
     * @see GameElement#draw()
     */
    @Override
    public void draw()
    {
        GameUtils.drawPoseAsTriangle(pose, SHIP_BASE, SHIP_HEIGHT);
    }

}
