import java.util.Random;

/**
 * An enumeration of different asteroid sizes.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 */
public enum AsteroidSize
{
    SMALL  (10, 200, .25),
    MEDIUM (20, 100, .25),
    LARGE  (30, 50, .5);
    
    private static final Random GENERATOR = new Random();
    private int radius;
    private int points;
    private double probability;
    
    
    /**
     * Constructs the AsteroidSize enum.
     * @param radius - radius of the asteroid type
     * @param points - points of the asteroid type
     * @param probability - probability of the asteroid occuring
     */
    private AsteroidSize(int radius, int points, double probability)
    {
        this.radius = radius;
        this.points = points;
        this.probability = probability;
    }
    
    /**
     * Get the radius of the asteroid type.
     * 
     * @return the radius as an int
     */
    public int getRadius()
    {
        return radius;
    }

    /**
     * Get the points of the asteroid type.
     * 
     * @return the points as an int
     */
    public int getPoints()
    {
        return points;
    }
    
    /**
     * Return a Asteroid Size based on a random number generated.
     * 
     * @return the generated AsteroidSize
     */
    public static AsteroidSize randomSize()
    {
        double random = GENERATOR.nextDouble();
        if (random < SMALL.probability)
        {
            return SMALL;
        }
        
        if (random < SMALL.probability + MEDIUM.probability)
        {
            return MEDIUM;
        }
        
        return LARGE;
    }
}
