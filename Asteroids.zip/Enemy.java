
/**
 * This class creates an enemy objects, an extension of 
 * GameElement.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public abstract class Enemy extends GameElement
{
    private int pointValue;
    
    /**
     * Constructs and enemy object with given parameters.
     * 
     * @param speed - the travel speed of the object
     * @param collisionRadius - the collision radius
     * @param pointValue - the point value of the object
     */
    public Enemy(double speed, double collisionRadius, 
            int pointValue)
    {
        super(speed, collisionRadius);
        this.pointValue = pointValue;
    }
    
    /**
     * Retrieve the point value of the enemy.
     * 
     * @return an int that represents point value
     */
    public int getPointValue()
    {
        return pointValue;
    }

    @Override
    public abstract void draw();
}
