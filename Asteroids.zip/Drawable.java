
/**
 * Interface for drawable objects in the 
 * asteroid game.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public interface Drawable
{
    /**
     * Tells subclasses to draw their object.
     * 
     */
    public void draw();
}
