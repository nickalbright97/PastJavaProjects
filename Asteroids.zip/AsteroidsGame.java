import java.util.ArrayList;

/**
 * Constructs Asteroid Game and allows it to be
 * updated and modified as needed.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/2018
 *e
 */
public class AsteroidsGame
{
    
    private static final double BULLET_SPEED = 20;
    private static final int VK_SPACE = 32;
    private ArrayList<Drawable> drawElements;
    private ArrayList<Updatable> updateElements;
    private ArrayList<GameElement> shipAndBullets;
    private ArrayList<Enemy> enemies;
    private GameElement ship;
    private final int numAsteroidsStart;
    private int score;
    private int lives;
    private BackgroundElement scoreDisplay;
    private BackgroundElement liveDisplay;
    
    
    
    /**
     * Constructs the asteroids game and initializes
     * default values.
     * 
     * @param numAsteroids - the number of asteroids to start with
     */
    public AsteroidsGame(int numAsteroids)
    {
        numAsteroidsStart = numAsteroids;
        
        drawElements = new ArrayList<Drawable>();
        updateElements = new ArrayList<Updatable>();
        shipAndBullets = new ArrayList<GameElement>();
        enemies = new ArrayList<Enemy>();
        
        score = 0;
        lives = 3;
        scoreDisplay = new NumericDisplay(60, 
                GameConstants.SCREEN_HEIGHT - 20, score, "Score: ");
        liveDisplay = new NumericDisplay(60, 
                GameConstants.SCREEN_HEIGHT - 60, lives, "Lives: ");
        drawElements.add(scoreDisplay);
        drawElements.add(liveDisplay);
        for (int k = 0; k < 100; k++)
        {
            drawElements.add(new Star());
        }
        
        ship = new Ship();
        addFriend(ship);
        
        
        for (int k = 0; k < numAsteroids; k++)
        {
            addEnemy(new Asteroid(AsteroidSize.randomSize()));
        }
        
    }
    
    /**
     * Update one time-step of the asteroid game when called.     * 
     * 
     */
    public void update()
    {
        if (lives > 0)
        {

            if (GameConstants.GENERATOR.nextDouble() < .002)
            {
                addEnemy(new Saucer());
            }
        

            for (int k = 0; k < updateElements.size() - 1; k++)
            {
                updateElements.get(k).update();
            }
            
            if (StdDraw.isKeyPressed(VK_SPACE))
            {
                GameElement bullet = new Bullet(new Pose(ship.getPose().getX(), 
                        ship.getPose().getY(), ship.getPose().getHeading()), 
                        new Vector2D(ship.getPose().getHeading(), BULLET_SPEED));
                addFriend(bullet);
            }
        

            for (int friend = shipAndBullets.size() - 1; friend >= 0; friend--)
            {    
            
                for (int enemy = enemies.size() - 1; enemy >= 0; enemy--)
                {
                    // longer variable names   
                    if (shipAndBullets.size() > 0 && enemies.size() > 0 
                            && friend < shipAndBullets.size())
                    {
                        if (shipAndBullets.get(friend).checkCollision(enemies.get(enemy)))
                        {
                            score += enemies.get(enemy).getPointValue();
                            ((NumericDisplay) scoreDisplay).setValue(score);

                            shipAndBullets.get(friend).destroy();
                         
                            enemies.get(enemy).destroy();
                        }
                    }
                }
            }
            
            for (int ship = shipAndBullets.size() - 1; ship >= 0; ship--)
            {
                if (shipAndBullets.get(ship).isDestroyed())
                {
                    removeFriend(shipAndBullets.get(ship));
                }
            }
        
            for (int enemy = enemies.size() - 1; enemy >= 0; enemy--)
            {
                if (enemies.get(enemy).isDestroyed())
                {
                    removeEnemy(enemies.get(enemy));
                }       
            }    
        
            if (enemies.isEmpty())
            {
                for (int k = 0; k < numAsteroidsStart; k++)
                {
                    addEnemy(new Asteroid(AsteroidSize.randomSize()));
                }
            }
        
                             
            if (ship.isDestroyed())
            {
                lives -= 1;
                ((NumericDisplay) liveDisplay).setValue(lives);
                ship = new Ship();
                addFriend(ship);
            }
        }


    
    }
    
    
    /**
     * Draw the asteroid game to screen when called.
     * 
     */
    public void draw()
    {
        StdDraw.setPenColor(255, 255, 255);   // white

        for (int k = 0; k < drawElements.size() - 1; k++)
        {
            drawElements.get(k).draw();
            
        }
    }
    
    /**
     * Add either a saucer or bullet to all the necessary
     * ArrayLists.
     * 
     * @param enemy - the enemy to be added
     */
    private void addEnemy(Enemy enemy)
    {
        drawElements.add(enemy);
        updateElements.add(enemy);
        enemies.add(enemy);
    }
    
    /**
     * Remove either a saucer or bullet from all necessary ArrayLists.
     * 
     * @param enemy - the enemy to be removed
     */
    private void removeEnemy(Enemy enemy)
    {
        drawElements.remove(enemy);
        updateElements.remove(enemy);
        enemies.remove(enemy);
    }
    
    /**
     * Add either a ship or bullet to necessary
     * ArrayLists.
     * 
     * @param friend - the friend to be added
     */
    private void addFriend(GameElement friend)
    {
        drawElements.add(friend);
        updateElements.add(friend);
        shipAndBullets.add(friend);
    }

    /**
     * Remove either a ship or bullet from necessary
     * ArrayLists.
     * 
     * @param friend - the friend to be removed
     */
    private void removeFriend(GameElement friend)
    {
        drawElements.remove(friend);
        updateElements.remove(friend);
        shipAndBullets.remove(friend);
    }
}
