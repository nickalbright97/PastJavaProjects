
/**
 * This class extends GameElement and is an encapsulation of
 * a bullet object.
 * 
 * @author Nick Albright
 * @version 1.0 4/04/18
 */
public class Bullet extends GameElement
{
    private static final double BULLET_RADIUS = 1.5;
    private static final int MAX_STEPS = 20;
    private int steps;
    
    
    /**
     * Constructs the bullet object.
     * 
     * @param pose - will be copied from ship firing bullet
     * @param velocity - 2D vector of the bullet's velocity
     */
    public Bullet(Pose pose, Vector2D velocity)
    {
        super(pose, velocity, BULLET_RADIUS);
        steps = 0;
    }
    
    /**
     * Update the position of the bullet and verify the bullet
     * has not reached 20 steps.
     * 
     * @see GameElement#update()
     */
    @Override
    public void update()
    {
        super.update();
        
        steps += 1;
        if (steps == MAX_STEPS)
        {
            destroy();
        }
        
        
    }

    /**
     * Draw the bullet.
     * 
     * @see GameElement#draw()
     */
    @Override
    public void draw()
    {
        StdDraw.filledCircle(pose.getX(), pose.getY(), 1);
    }

}
