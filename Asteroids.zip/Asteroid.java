
/**
 * An encapsulation of an Asteroid object.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/2018
 */
public class Asteroid extends Enemy
{
    private static final double ASTEROID_SPEED = 1;
    private AsteroidSize size;   
        
    /**
     * Constructor for Asteroid.
     * 
     * @param size - either SMALL, MEDIUM, or LARGE
     */
    public Asteroid(AsteroidSize size)
    {
        super(ASTEROID_SPEED, 
                size.getRadius(), size.getPoints());
        this.size = size;
    }
    
   

    /**
     * Draw the asteroid.
     * 
     * @see Enemy#draw()
     */
    @Override
    public void draw()
    {
        StdDraw.setPenRadius(.002);
        StdDraw.circle(pose.getX(), pose.getY(), size.getRadius());        
    }

}
