
/**
 * Class which builds a general background element.
 * 
 * @author Nick ALbright
 * @version 1.0 04/04/18
 *
 */
public abstract class BackgroundElement implements Drawable
{
    protected Point location;
    
    /**
     * Constructs the Background Element.
     * @param xPosition of the center of the element
     * @param yPosition of the center of the element
     */
    public BackgroundElement(double xPosition, double yPosition)
    {
        location = new Point(xPosition, yPosition);
    }
    
    /** 
     * Abstract method to draw an element in a subclass.
     * 
     * @see Drawable#draw()
     */
    public abstract void draw();
}
