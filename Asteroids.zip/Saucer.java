
/**
 * Creates a Saucer object. This is a subclass of Enemy.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public class Saucer extends Enemy
{
    private static final double SAUCER_SPEED = 2;
    private static final double COLLISION_RADIUS = 10;
    private static final double WIDTH = 20;
    private static final double HEIGHT = 10;
    private static final int POINT_VALUE = 400;
    
    
    /**
     * Creates a saucer object. This uses the three parameter
     * constructer in the superclass.
     * 
     * 
     */
    public Saucer()
    {
        super(SAUCER_SPEED, COLLISION_RADIUS, POINT_VALUE);
    }
    
    /**
     * Update the position and destroyed status of the
     * saucer. 
     * 
     * @see GameElement#update()
     */
    @Override
    public void update()
    {
        if (GENERATOR.nextDouble() < .05)
        {
            velocity.setHeading(GENERATOR.nextDouble() * 2 * Math.PI);
        }
        
        if (pose.getX() + velocity.getX() > GameConstants.SCREEN_WIDTH
                || pose.getX() + velocity.getX() < 0 
                || pose.getY() + velocity.getY() > GameConstants.SCREEN_HEIGHT 
                || pose.getY() + velocity.getY() < 0)
        {
            destroy();
        }
        
        super.update();       
    }

    /**
     * Draw the saucer object.
     * 
     * @see Enemy#draw()
     */
    @Override
    public void draw()
    {
        StdDraw.setPenRadius(.002);
        StdDraw.rectangle(pose.getX(), pose.getY(), 
                WIDTH / 2, HEIGHT / 2);

    }

}
