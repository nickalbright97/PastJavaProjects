
/**
 * An interface for updatable objects in the 
 * asteroids game.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public interface Updatable
{
    /**
     * Update the object.
     * 
     */
    public void update();
}
