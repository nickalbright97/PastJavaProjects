
/**
 * Create a stationary star object for Asteroids.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public class Star extends BackgroundElement
{   
    
    private static final double STAR_RADIUS = 1; 
    
    /**
     * Create a star object.
     * 
     */
    public Star()
    {
        super(GameConstants.GENERATOR.nextDouble() * 480, 
                GameConstants.GENERATOR.nextDouble() * 480);
    }

    /**
     * Draw the star object.
     * 
     * @see BackgroundElement#draw()
     */
    @Override
    public void draw()
    {
        StdDraw.filledCircle(location.getX(), location.getY(), STAR_RADIUS);
    }

}
