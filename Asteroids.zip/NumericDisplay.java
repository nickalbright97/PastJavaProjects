
/**
 * This class creates a numeric display for score
 * displaying and lives remainng purposes.
 * 
 * @author Nick Albright
 * @version 1.0 04/04/18
 *
 */
public class NumericDisplay extends BackgroundElement
{
    private int value;
    private String prefix;

    /**
     * Construct the numeric display.
     * 
     * @param xPos - center of display on x axis
     * @param yPos - center of display on y axis
     * @param value - the number displayed
     * @param prefix - the string displayed before the number
     */
    public NumericDisplay(int xPos, int yPos,
            int value, String prefix)
    {
        super(xPos, yPos);
        this.value = value;
        this.prefix = prefix;        
    }
    
    /**
     * Set the value on the display.
     * 
     * @param value 
     */
    public void setValue(int value)
    {
        this.value = value;
    }
    
    /**
     * Draw the background element.
     * 
     * @see BackgroundElement#draw()
     */
    @Override
    public void draw()
    {
        StdDraw.text(location.getX(), location.getY(), 
                prefix + Integer.toString(value));        
    }

}
