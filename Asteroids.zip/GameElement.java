import java.util.Random;

/**
 * A general class of a GameElement for Asteroids
 * 
 * @author Nick
 * @version 1.0 04/04/2018
 *
 */
/**
 * @author Nick
 *
 */
public abstract class GameElement implements Updatable, Drawable
{
    protected static final Random GENERATOR = new Random();
    protected Pose pose;
    protected Vector2D velocity;
    protected boolean destroyed;
    protected double collisionRadius;
    

    
    /**
     * Constructs a GameElement object.
     * 
     * @param pose - pose of the object
     * @param velocity - the velocity vector of the object
     * @param collisionRadius - the collision radius
     */
    public GameElement(Pose pose, Vector2D velocity, 
            double collisionRadius)
    {
        this.pose = pose;
        this.velocity = velocity;
        this.collisionRadius = collisionRadius;
        destroyed = false;
    }
    
    /**
     * This constructs a GameElement object with just two attributes and the rest
     * are generated randomly.
     * 
     * @param speed - the magnitude of the object's velocity
     * @param collisionRadius - the collision radius
     */
    public GameElement(double speed, double collisionRadius)
    {
        pose = new Pose(GENERATOR.nextDouble() * 480, 
                GENERATOR.nextDouble() * 480, GENERATOR.nextDouble() * 2 * Math.PI);
        velocity = new Vector2D(GENERATOR.nextDouble() * 2 * Math.PI, speed);
        this.collisionRadius = collisionRadius;
    }
    
    /** 
     * Update the game element's position.
     * 
     * @see Updatable#update()
     */
    public void update()
    {
        pose.setX(pose.getX() + velocity.getX());
        pose.setY(pose.getY() + velocity.getY());
        
        // Wrap at edges
        if (pose.getX() > GameConstants.SCREEN_WIDTH)
        {
            pose.setX(pose.getX() % GameConstants.SCREEN_WIDTH);
        }
        else if (pose.getX() < 0)
        {
            pose.setX(GameConstants.SCREEN_WIDTH - pose.getX());
        }
        
        if (pose.getY() > GameConstants.SCREEN_HEIGHT)
        {
            pose.setY(pose.getY() % GameConstants.SCREEN_HEIGHT);
        }
        else if (pose.getY() < 0)
        {
            pose.setY(GameConstants.SCREEN_HEIGHT - pose.getY());
        }
    }
    
    /**
     * Check to see if the game element has collided with another.
     * @param other - the game element to be compared to
     * @return boolean - true if the elements collide
     */
    public boolean checkCollision(GameElement other)
    {
        double xDif = pose.getX() - other.pose.getX();
        double yDif = pose.getY() - other.pose.getY();
        double radiusTot = collisionRadius + other.collisionRadius;
        
        return xDif * xDif + yDif * yDif <= radiusTot * radiusTot;
    }
    
    /**
     * Change the boolean value destroyed to true.
     * 
     */
    public void destroy()
    {
        destroyed = true;
    }
    
    /**
     * Check whether the game element is destroyed.
     * 
     * @return boolean - true if element is destroyed
     */
    public boolean isDestroyed()
    {
        return destroyed;
    }
    
    /**
     * Return the pose of the game element.
     * 
     * @return Pose - the pose of the element
     */
    public Pose getPose()
    {
        return pose;
    }
    
    /**
     * Abstract draw method to be implemented by sub-classes.
     * 
     * @see Drawable#draw()
     */
    public abstract void draw();

}
