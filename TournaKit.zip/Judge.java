/*
   * This work complies with the JMU Honor Code.     
   *  
   * References and Acknowledgments: I received no outside help with this
   * programming assignment.
   */


/**
 * This interface implements classes to determine result
 * of a given matchup.
 * 
 * @author Nick Albright
 * @version 1.0 4/16/18
 * 
 *
 */
public interface Judge
{
    /** 
     * Will tell implementing classes how to determine
     * result.
     * 
     * @param matchup - matchup to be analyzed
     * @param who - participant who wins/loses/ties
     * @return - the int which communicates result
     */
    public int result(Matchup matchup, Participant who);

}
