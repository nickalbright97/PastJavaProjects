
/**
 * This class implements the judge interface for competitions where
 * the high score wins.
 * 
 * @author Nick Albright
 * @version 1.0 4/16/18
 *
 */
public class HighWins implements Judge
{

    @Override
    public int result(Matchup matchup, Participant who)
    {
        int scoreWho = matchup.getScore(who);
        int scoreOther = matchup.getScore(who.other());
        
        if (scoreWho > scoreOther)
        {
            return 1;
        }
        
        if (scoreWho < scoreOther)
        {
            return -1;
        }
        
        return 0;
    }

}
