import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;


/**
 * A utility class for performing calculations on tournaments.
 * 
 * @author Nick Albright
 * @version 1.0 4/16/18
 *
 */
public class Analyst
{
    /**
     * Get the total point differential across every matchup for a given
     * team up until the ending matchup.
     * 
     * @param t - single elim tournamne to be analyzed
     * @param endingWith - last matchup
     * @param team - team to be analyzed
     * @return int - total point differential
     */
    public static int totalPointDifferential(Tournament t, 
            Matchup endingWith, String team)
    {
        int pointDiff = 0;
        Iterator<Matchup> it = t.iterator(endingWith, team);
        while (it.hasNext())
        {
            Matchup match = it.next();
            pointDiff += matchPointDifferential(match);
        }
        
        return pointDiff;
    }
    
    /**
     * Calculate the point differential (absolute value) of a given match.
     * 
     * @param match - match to be analyzed
     * @return an int that is the point differential
     */
    private static int matchPointDifferential(Matchup match)
    {
        return Math.abs(match.getScore(Participant.HOME) - match.getScore(Participant.VISITOR));
    }
    
    /**
     * This creates a schedule for each team in the round robin tournament.
     * 
     * @param t - RoundRobinTournament from which schedule is created
     * @return HashMap - key is the string name of a team and value is an arraylist of opponents
     */
    public static HashMap<String, ArrayList<String>> buildSchedule(RoundRobinTournament t)
    {
        HashMap<String, ArrayList<String>> schedule = new HashMap<String, ArrayList<String>>();
         
        Matchup[] matchups = t.getFinalMatchups();
        for (int k = 0; k < matchups.length; k++)
        {
            if (!(schedule.containsKey(matchups[k].getName(Participant.HOME))))
            {
                ArrayList<String> opponents = new ArrayList<String>();
                opponents = getOpponents(t, matchups[k], 
                        matchups[k].getName(Participant.HOME), opponents);
                schedule.put(matchups[k].getName(Participant.HOME), 
                        opponents);
            }
            
            if (!(schedule.containsKey(matchups[k].getName(Participant.VISITOR))))
            {
                ArrayList<String> opponents = new ArrayList<String>();
                opponents = getOpponents(t, matchups[k], 
                        matchups[k].getName(Participant.VISITOR), opponents);
                schedule.put(matchups[k].getName(Participant.VISITOR), 
                        opponents);
            }
        }
        return schedule;
    }
    
    /**
     * Recursive method which helps with opponent retrieval through
     * different rounds of a tournament.
     * 
     * @param t - analyzed tournament
     * @param match - the match from which opponent should be retrieved
     * @param team - the team whose opponents are being added.
     * @param opponents - the arraylist being updated.
     * @return an arraylist which houses opponets of the team provided
     */
    private static ArrayList<String> getOpponents(RoundRobinTournament t, Matchup match, 
            String team, ArrayList<String> opponents)
    {
        if (!(match == null))
        {
            if (match.getName(Participant.HOME).equals(team))
            {
                opponents.add(0, match.getName(Participant.VISITOR));
            }
            else
            {
                opponents.add(0, match.getName(Participant.HOME));
            }
            return getOpponents(t, t.previous(match, team), team, opponents);
        }
        return opponents;
    }
    
    /**
     * Calculates the total (absolute value) point differential in a 
     * single elimination tournament.
     * 
     * @param t - the tournament to be analyzed
     * @return int - the total point differential
     */
    public static int totalPointDifferential(SingleEliminationTournament t)
    {
        return getTotalPoints(t, t.getFinalMatchup(), 0);
    }
    
    /**
     * Recursive helper method to calculate the total point differential
     * throughout a single elimination tournament.
     * 
     * @param t - the tournament to be analyzed
     * @param match - the match to be analyzed
     * @param total - the total point differential
     * @return an int that represents total point differential (absolute value)
     */
    private static int getTotalPoints(SingleEliminationTournament t, Matchup match, int total)
    {
        int sum = total + matchPointDifferential(match);
        if (!(t.previous(match, match.getName(Participant.HOME)) == null))
        {
            sum += getTotalPoints(t, t.previous(match, match.getName(Participant.HOME)), 0);
        }
        // Could use optimization
        if (!(t.previous(match, match.getName(Participant.VISITOR)) == null))
        {
            sum += getTotalPoints(t, t.previous(match, match.getName(Participant.VISITOR)), 0);
        }
        
        return sum;
    }
    
    /**
     * Build a schedule for each team in the single elimination tournament provided.
     * 
     * @param t - the tournament to be analyzed
     * @return a HashMap where the key is the team and the value is an arraylist of its schedule
     */
    public static HashMap<String, ArrayList<String>> buildSchedule(SingleEliminationTournament t)
    {
        HashMap<String, ArrayList<String>> schedule = new HashMap<String, ArrayList<String>>();
        return getOpponents(t, t.getFinalMatchup(), schedule);
        
    }
    
    /**
     * Recursive helper method used by buildSchedule(SingleElim).
     * 
     * @param t - single elim tournament to be analyzed
     * @param match - match currently analyzed
     * @param schedule - hashmap to be added to
     * @return the hashmap returned
     */
    private static HashMap<String, ArrayList<String>> getOpponents(SingleEliminationTournament t, 
            Matchup match, HashMap<String, ArrayList<String>> schedule)
    {
        if (!(match == null))
        {
            String home = match.getName(Participant.HOME);
            String visitor = match.getName(Participant.VISITOR);
            if (!(schedule.containsKey(home)))
            {
                ArrayList<String> opponents = new ArrayList<String>();
                opponents.add(visitor);
                schedule.put(home, opponents);
            }
            else
            {
                schedule.get(home).add(0, visitor);
            }
            
            if (!(schedule.containsKey(visitor)))
            {
                ArrayList<String> opponents = new ArrayList<String>();
                opponents.add(home);
                schedule.put(visitor, opponents);
            }
            else
            {
                schedule.get(visitor).add(0, home);
            }
            
            schedule.putAll(getOpponents(t, t.previous(match, home), schedule));
            schedule.putAll(getOpponents(t, t.previous(match, visitor), schedule));
        }
        return schedule;
    }
    
    /**
     * This method calculates records for every team in a tournament.
     * 
     * @param t - the tournament, either type
     * @param j - the judge, highwins or lowwins
     * @return a hashmap where key is the string name of a team and records are
     * in the value
     */
    public static HashMap<String, Record> calculateRecords(Tournament t, Judge j)
    {
        HashMap<String, Record> records = new HashMap<String, Record>();
        
        HashSet<Matchup> matchSet = new HashSet<Matchup>();
        
        Matchup[] matchups = t.getFinalMatchups();
        for (int k = 0; k < matchups.length; k++)
        {
            records = recursiveRecords(t, j, records, matchups[k], matchSet);
        }
        
        return records;
        
    }
    
    /**
     * A private recursive helper method to determine the hashmap
     * for the method calculateRecords.
     * 
     * @param t - the tournament to be analyzed
     * @param j - the judge
     * @param records - the hashmap passed recursively
     * @param match - the current match analyzed
     * @param matchSet - checks for uniqueness of match
     * @return - the hashmap being altered
     */
    private static HashMap<String, Record> recursiveRecords(Tournament t, Judge j, HashMap<String, 
            Record> records, Matchup match, HashSet<Matchup> matchSet)
    {
        if (match == null)
        {
            return records;
        }
        
        if (!matchSet.add(match))
        {
            return records;
        }
        
        String home = match.getName(Participant.HOME);
        String visitor = match.getName(Participant.VISITOR);
        Record copyRecord;
        if (!(records.containsKey(home)))
        {
            Record record = new Record();
            record = modifyRecord(match, Participant.HOME, j, record);
            records.put(home, record);
        }
        else
        {
            copyRecord = records.get(home);
            copyRecord = modifyRecord(match, Participant.HOME, j, copyRecord);
        }
        
        if (!(records.containsKey(visitor)))
        {
            Record record = new Record();
            record = modifyRecord(match, Participant.VISITOR, j, record);
            records.put(visitor, record);
        }
        else
        {
            copyRecord = records.get(visitor);
            copyRecord = modifyRecord(match, Participant.VISITOR, j, copyRecord);
        }
            
        records.putAll(recursiveRecords(t, j, records, t.previous(match, home), matchSet));
        records.putAll(recursiveRecords(t, j, records, t.previous(match, visitor), matchSet));
        
        return records;
    }
        
    /**
     * Helper method which performs record manipulation.
     * 
     * @param matchup - matchup where record is analyzed
     * @param who - participant whose record is changed
     * @param j - judge used in this situation
     * @param record - record to be changed
     * @return the changed record 
     */
    private static Record modifyRecord(Matchup matchup, Participant who, Judge j, Record record)
    {
        if (j.result(matchup, who) == 1)
        {
            record.increaseWins();
        }
        else if (j.result(matchup, who) == -1)
        {
            record.increaseLosses();
        }
        else 
        {
            record.increaseTies();
        }
        
        return record;
        
    }
   
}
