
/**
 * An encapuslation of a competitor's performance
 * in a tournament.
 * 
 * @author Nick Albright
 * @version 1.0 4/16/18
 */
public class Record
{
    private int losses;
    private int ties;
    private int wins;
    
    /**
     * Initialize records at 0-0-0.
     */
    public Record()
    {
        losses = 0;
        ties = 0;
        wins = 0;
    }
    
    /**
     * Initialize a record with given parameters.
     * @param wins - number of wins of team
     * @param losses - losses of team
     * @param ties - ties of team
     */
    public Record(int wins, int losses, int ties)
    {
        this.wins = wins;
        this.losses = losses;
        this.ties = ties;
    }
    
    /**
     * Return losses.
     * @return int - losses
     */
    public int getLosses()
    {
        return losses;
    }
    
    /**
     * Return ties.
     * @return int - ties
     */
    public int getTies()
    {
        return ties;
    }
    
    /**
     * Return wins.
     * @return int - wins
     */
    public int getWins()
    {
        return wins;
    }
    
    /**
     * Increase losses by 1.
     * 
     */
    public void increaseLosses()
    {
        losses += 1;
    }
    
    /**
     * Increase wins by 1.
     * 
     */
    public void increaseWins()
    {
        wins += 1;
    }
    
    /**
     * Increase ties by 1.
     * 
     */
    public void increaseTies()
    {
        ties += 1;
    }
    
    /**
     * This creates a string object for output.
     * 
     * @return the String desired
     */
    public String toString()
    {
        return String.format("%3d - %3d - %3d", wins, losses, ties);
    }

}
